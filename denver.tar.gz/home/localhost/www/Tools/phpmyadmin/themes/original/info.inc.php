<?php
/* $Id$ */
/* Theme information */
$theme_name = 'Original';
$theme_version = 1;
$theme_generation = 1;
?>
