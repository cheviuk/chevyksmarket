<?php

	$login=$_POST["login"];
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT email, password FROM users WHERE login = '$login'");
	
	$row=mysql_fetch_array($mq);
	mail("$row[0]","склероз","купи моск! вот пасс: $row[1]");
	echo "сообщение было отправлено";






?>