<html>
<body>
�������:<br />
<?php

	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT * FROM friends");
	while($row=mysql_fetch_array($mq))
	{
		echo "<a href=\"$row[2]\">$row[1]</a><br />";
	}





?>
</body>
</html>