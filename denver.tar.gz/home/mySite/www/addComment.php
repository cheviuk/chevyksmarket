<?php
	
	$name=$_POST["name"];
	$text=$_POST["text"];
	for($i=0;$i<strlen($text);$i++)
	{
		if($i%20==0)
		{
			echo "!";
		}
	}
	$id_product=$_GET["id"];
	$rating=$_POST["rating"];
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	mysql_query("INSERT INTO comments (id_product, name, text, rating) VALUES ($id_product, '$name', '$text', $rating)");
		#
		echo "<META HTTP-EQUIV=refresh CONTENT=\"0;url=index.php?page=product&id=$id_product\">";
?>