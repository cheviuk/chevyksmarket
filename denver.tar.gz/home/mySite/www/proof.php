<?php
	session_start();
	$login= $_POST["login"];
	$password=$_POST["password"];
	mysql_connect("localhost","user","1111");
	mysql_query("use TEST");
	$mq=mysql_query("select * from users where (login like '$login' and password like '$password')");
	
	if(mysql_num_rows($mq))
	{
		$_SESSION["name"]=$login;
		//перенаправляем на index.php
		header('Location: index.php');
		
	}
	else
	{
		//перенаправляем на index.php?page=invalidAuthorization
		echo "<META HTTP-EQUIV=refresh CONTENT=\" 0 ;url=index.php?page=invalidAuthorization\">";
		
	}

?>