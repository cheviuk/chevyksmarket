<?php

	session_start();
	$user=$_SESSION["name"];
	mysql_connect("localhost", "user", "1111");
	mysql_query("use test");
	$mq=mysql_query("SELECT * FROM orders WHERE userName like '$user'");
	
	while($row=mysql_fetch_array($mq))
	{
		$mq2=mysql_query("SELECT * FROM products WHERE id LIKE $row[2]");
		$row2=mysql_fetch_array($mq2);
		echo "<div class=\"orderedProducts\">$row[0] $row[3] <a href=index.php?page=product&id=$row[2]>$row2[1]</a> <a href=deleteFromCart.php?id=$row[0]>delete</a></div><br />";
	}

	
	
	

?>