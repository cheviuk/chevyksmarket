<?php 
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	mysql_query("DELETE FROM manufacturers WHERE name = '".$_POST["selectedVendor"]."'");
	
	header("Location: administrator.php");
?>