<html>
<head>
</head>
<body>
<script type="text/javascript">
function chk()
{
	
	document.getElementById("textLogin").style.color= "lime";
	document.getElementById("textName").style.color= "lime";
	document.getElementById("textPassword").style.color= "lime";
	document.getElementById("textConfirm").style.color= "lime";
	document.getElementById("textEmail").style.color= "lime";
	document.getElementById("textLogin").style.color= "lime";
	
	
	var name=form1.name.value.toString();
	var surname=form1.surname.value.toString();
	var login=form1.login.value.toString();
	var login = form1.login.value.toString();
	var password=form1.password.value.toString();
	var confirm=form1.confirm.value.toString();
	var email=form1.email.value.toString();
	var phone=form1.phone.value.toString();
	
	
	if(login!="")
	{
	
		if(password!="")
		{
			if(confirm==password)
			{
				if(email!="")
				{
					form1.submit();
				}
				else
				{
					if(login=="")
					{
						document.getElementById("textLogin").style.color= "red";
					}
					if(password=="")
					{
						document.getElementById("textPassword").style.color= "red";
					}
					document.getElementById("textEmail").style.color= "red";
				}
			}
			else
			{
				
				
				document.getElementById("textConfirm").style.color= "red";
				document.getElementById("textPassword").style.color= "red";
			}
		}
		else
		{
		
			document.getElementById("textPassword").style.color= "red";
			if(email=="")
		{
			document.getElementById("textEmail").style.color= "red";
		}
		if(login=="")
		{
			document.getElementById("textLogin").style.color= "red";
		}
		}
	}
	else
	{
		
		document.getElementById("textLogin").style.color= "red";
		if(password=="")
		{
			document.getElementById("textPassword").style.color= "red";
		}
		if(email=="")
		{
			document.getElementById("textEmail").style.color= "red";
		}
		
	}
	
}
</script>
<div class ="registrationDiv">
<form action="index.php?page=successRegistration" method="post" name="form1">
<input type=text name="name" id="name" /><span id="textName">name</span><br />
<input type=text name="surname" id="surname" /><span id="textSurname">surname</span><br />
<input type=text name="login" id="login" /><span id="textLogin">login*</span><br />
<input type=password name="password" id="password" /><span id="textPassword">password*</span><br />
<input type=password name="confirm" id="confirm" /><span id="textConfirm">confirm*</span><br />
<input type=text name="email" id="email" /><span id="textEmail">email*</span><br />
<input type=text name="phone" id="phone" /><span id="textPhone">phone</span><br />
</div>
<?php 
	
	echo("<select name=\"day\" id=\"day\">");
for($i=1;$i<32;$i++)
{
	echo("<option>".$i."</option>");
	
	
}
echo("</select>");
//
	echo("<select name=\"month\" id=\"month\">");
for($i=1;$i<13;$i++)
{
	echo("<option>".$i."</option>");
	
	
}
echo("</select>");
//
	echo("<select name=\"year\" id=\"year\">");
for($i=1950;$i<2000;$i++)
{
	echo("<option>".$i."</option>");
	
	
}
echo("</select><br />");

?>
<input type="button" name="btn_name" value="submit" onclick="chk();">
</form>

</body>
</html>