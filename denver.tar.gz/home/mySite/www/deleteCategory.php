<?php 
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	mysql_query("DELETE FROM categories WHERE name = '".$_POST["selectedCategory"]."'");
	
	header("Location: administrator.php");
?>