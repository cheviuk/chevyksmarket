<html>
<head>
<link type="text/css" rel="stylesheet" href="style.css" />
</head>
<body>

<div id="menuDiv">
<div class=menuDiv>categories:</div></div><br />
<?php

mysql_connect("localhost","user","1111");
mysql_query("use test");
$mq=mysql_query("SELECT * FROM `categories`");
while($row=mysql_fetch_array($mq))
{	
	$encoded=urlencode($row[1]);
	if($_GET["category"]==$row[1])
		echo("<a id=\"menuLink\" href=index.php?page=category&category=$encoded&pagen=1><div id=\"menuItem\"><span class=arrows>></span><span class=\"cur\">$row[1]</span><span class=arrows><</span></div></a><br />");
	else
		echo("<a id=\"menuLink\" href=index.php?page=category&category=$encoded&pagen=1><div id=\"menuItem\">$row[1]</div></a><br />");

}



?>

</body>
</html>