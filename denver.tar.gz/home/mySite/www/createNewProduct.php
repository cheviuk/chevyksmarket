<?php
	
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	
	
	$name=$_POST["name"];
	$price=$_POST["price"];
	$description=$_POST["description"];
	$fullDescription=$_POST["fullDescription"];
	$picture=$_POST["picture"];
	$id_category;
	$id_manufacturer;
	$mq1=mysql_query("SELECT * FROM categories WHERE name = '".$_POST["category"]."'");
	$mqRow1=mysql_fetch_array($mq1);
	$id_category=$mqRow1[0];
	$mq2=mysql_query("SELECT * FROM manufacturers WHERE name = '".$_POST["manufacturer"]."'");
	$mqRow2=mysql_fetch_array($mq2);
	$id_manufacturer=$mqRow2[0];
	mysql_query("INSERT INTO products (name, price, description, fullDescription, picture, id_category, id_manufacturer) VALUES ('$name', '$price', '$description', '$fullDescription', '$picture', '$id_category', '$id_manufacturer')");

	
	
	header("Location: administrator.php");
	
?>