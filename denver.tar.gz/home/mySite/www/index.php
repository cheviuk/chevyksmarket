<?php session_start();?>
<html>
<head>
<link href="favicon.ico" rel="icon" type="image/x-icon" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link rel="stylesheet"  type="text/css" href="style.css" />
</head>
<body>

<div class="mainMainDiv">
<div class="mainDiv">


<table class="mainTable">
	<tr>
		<td class="headCol" colspan=3>&nbsp; <a href=index.php><!--<img height=100 border=0 src="logo.png" />--><?php include("logo.php");?></a></td>
	</tr>
	<tr>
		<td class="leftCol">&nbsp;
		<div class="menu"><?php include("menu.php");?></div>
		<div class="authorization">
		<?php
		
			
			if(isset($_SESSION["name"])==1)
			{
				$sessionName =$_SESSION["name"];
				echo("<div class=\"successAuthorization\">������, $sessionName<br /><a href=\"index.php?page=editPersonalInformation\"><img border=0 src=\"http://tbn3.google.com/images?q=tbn:KfPzmpWvd605aM:http://www.tvoya-statya.ru/images/info.png\" /></a> <a href=\"index.php?page=cart\"><img border=0 src=\"http://tbn0.google.com/images?q=tbn:9XokHttw4nHpZM:http://www.service-manual.ru/images/header_cart.gif\" /></a><a href=index.php?page=exit><img border=0 src=\"http://tbn0.google.com/images?q=tbn:Chk8jgvI_nTCKM:http://milanfan.ucoz.ua/exit.jpg\" /></a></div>");
				if($sessionName=="admin")
				{
					echo "<a href=administrator.php><img src=admin.jpg width=50 height=50 /></a>";
				}
			}	
			else
			{
				//echo("<div class=\"authorization\">");
				include("authorization.php");
				//echo("</div>");
			}
		?>
		</div>
		
		<div class="friends"><?php include("friends.php");?></div>
		</td>
		<td class="middleCol">&nbsp;
		
		<?php 
			
			if(isset($_GET["page"]))
			{
				if($_GET["page"]=="registration")
				{
					include("registration.php");
				}
				
				//
				if($_GET["page"]=="successRegistration")
				{
					include("successRegistration.php");
				}
				//
				
				if($_GET["page"]=="exit")
				{
					session_destroy();
					echo("����� ���������� ����� ���� ���");
					echo ("<META HTTP-EQUIV=refresh CONTENT=\"2;url=index.php\">");
				}
				if($_GET["page"]=="category")
				{
					$categ=$_GET["category"];
					
					
					include("products.php");
				}
				if($_GET["page"]=="invalidAuthorization")
				{
					//echo("�� ����� ����������� ����� ���� ������!<br />");
					include("authorization.php");
				}
				if($_GET["page"]=="product")
				{
					include("product.php");
				}
				if($_GET["page"]=="editPersonalInformation")
				{
					if(isset($_SESSION["name"]))
					{
						include("editPersonalInformation.php");
					}
				}
				if($_GET["page"]=="cart")
				{
					include("cart.php");
				}
				if($_GET["page"]=="remember")
				{
					include("remember.php");
				}
				if($_GET["page"]=="passToMail")
				{
					include("passToMail.php");
				}
			}
			else
			{
				$category="all";
				mysql_connect("localhost","user","1111");
				$mq=mysql_query("use test");
				
					
				$mq=mysql_query("select * from products ORDER BY id DESC LIMIT 5");
				
				for($i=0;$i<mysql_num_rows($mq);$i++)
				{
					$rowProduct=mysql_fetch_array($mq);
					echo "<div class=\"product\"><table >";
					echo "<tr><td colspan=6><img src=$rowProduct[5] /></td></tr><tr ><td><a href=index.php?page=product&id=$rowProduct[0]>$rowProduct[1]</a></td><td>$rowProduct[2]</td><td>$rowProduct[3]</td><td>"./*$category*/"</td></tr></table></div>";
					
				}
			}
			
			
		?>
		
		 
		
		
		
		
		</td>
		<td class="rightCol">&nbsp;<?php include("babosy.php");?></td>
	</tr>
	<tr>
		<td class="footCol" colspan=3>&nbsp;��������-������� "": ������ ""<br />developed by chevyk
	</tr>

</table>



</div>
</div>

</body>
</html>