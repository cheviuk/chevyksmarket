<?php 
	session_start();
	if($_SESSION["name"]!="admin")
	{
		echo "������, �����! ��� ��� �������!";
		echo "<META HTTP-EQUIV=refresh CONTENT=\"1;url=index.php\">";
	}
	else
		echo "������, ����������!<br />";
		echo "<a href=index.php>�� ����</a>";

?>
<html>
<head></head>
<body>

<?php #add new vendor, delete vendor
echo "<br />vendors: <br />";
echo "<div><form name=form1 method=post action=\"createNewVendor.php\"><input type=text name=nameOfNewVendor id=nameOfNewVendor /><input type=submit value=create /></form></div>";



	echo "<div><form name=form2 method=post action=\"deleteVendor.php\">";
	echo "<select id=selectedVendor name=selectedVendor>";
	
	
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT * FROM manufacturers");
	
	while($row=mysql_fetch_array($mq))
	{	
		echo "<option value=$row[1]>".$row[1]."</option>";
	}
	echo "</select>";
	echo "<input type=submit value=delete>";
	echo "</form></div>";



?>

<?php #add new category, delete new category =)
echo "categories: <br />";
	echo "<div><form name=form3 method=post action=\"createNewCategory.php\"><input type=text name=nameOfNewCategory id=nameOfNewCategory /><input type=submit value=create /></form></div>";

	
	echo "<div><form name=form4 method=post action=\"deleteCategory.php\">";
	echo "<select id=selectedCategory name=selectedCategory>";
	
	
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT * FROM categories");
	
	while($row=mysql_fetch_array($mq))
	{	
		echo "<option value=$row[1]>".$row[1]."</option>";
	}
	echo "</select>";
	echo "<input type=submit value=delete>";
	echo "</form></div>";

?>
<?php #add new product
echo "products creator: <br />";

	echo "<div><form name=form5 method=post action=createNewProduct.php>";
	echo "<input type=text id=name name=name maxlength=255 />name<br />";
	echo "<input type =text id=price name=price />price<br />";
	echo "<input type =text id=description name=description />description<br />";
	echo "<input type =text id=fullDescription name=fullDescription />full description<br />";
	echo "<input type =text id=picture name=picture />picture<br />";
	
	echo "<select name=category>";
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT * FROM categories");
	while($row=mysql_fetch_array($mq))
	{
		echo "<option>$row[1]</option>";
	}
	echo "</select>category";
	
	echo "<br />";
	
	echo "<select name=manufacturer>";
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT * FROM manufacturers");
	while($row=mysql_fetch_array($mq))
	{
		echo "<option>$row[1]</option>";
	}
	echo "</select>vendor<br />";
	echo "<input type=submit value=add />";
	echo "</form>";
?>
<?php

include("formUpload.php");

?>


</body>
</html>