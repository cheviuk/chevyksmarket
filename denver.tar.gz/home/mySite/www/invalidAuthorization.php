<?php 
	
	
	header("Location: index.php?page=invalidAuthorization");

?>