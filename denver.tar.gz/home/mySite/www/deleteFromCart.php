<?php
	
	session_start();
	$userName=$_SESSION["name"];
	$id=$_GET["id"];
	mysql_connect("localhost","user", "1111");
	mysql_query("USE test");
	mysql_query("DELETE FROM orders WHERE id LIKE $id");
	
	echo "<META HTTP-EQUIV=refresh CONTENT=\"0;url=index.php?page=cart\">";
	
?>