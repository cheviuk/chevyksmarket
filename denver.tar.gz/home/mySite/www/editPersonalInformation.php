
<html><head></head><body>

<form action="changePersonalInformation.php" method="post" name="form1">
<input type=text name="name" id="name" /><span id="textName">name</span><br />
<input type=text name="surname" id="surname" /><span id="textSurname">surname</span><br />
<input type=text name="phone" id="phone" /><span id="textPhone">phone</span><br />
</div>

<input type="submit" name="btn_name" value="submit">
</form>

</body></html>
<?php


	$session=$_SESSION["name"];
	
	mysql_connect("localhost", "user", "1111");
	$mq=mysql_query("select name, surname, phone from users where login like '$session'");
	$row=mysql_fetch_array($mq);
	echo "$session $row[0] $row[1] $row[2]";
	echo "<script type=\"text/javascript\">document.getElementById(\"name\").value=\"$row[0]\"; document.getElementById(\"surname\").value=\"$row[1]\"; document.getElementById(\"phone\").value=\"$row[2]\";</script>";


?>