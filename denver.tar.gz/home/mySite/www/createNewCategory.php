<?php
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("INSERT INTO categories (name) VALUES ('".$_POST["nameOfNewCategory"]."')");
	header("Location: administrator.php");
?>