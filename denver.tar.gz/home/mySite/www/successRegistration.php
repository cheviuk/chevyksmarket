<html>
<body>
<?php

if(isset($_POST["login"]))
{
	if(isset($_POST["password"])&&isset($_POST["confirm"]))
	{
		if($_POST["password"]==$_POST["confirm"])
		{
			if(isset($_POST["email"])&&isset($_POST["phone"]))
			{
				$name=$_POST["name"];
				$surname=$_POST["surname"];
				$login=$_POST["login"];
				$password=$_POST["password"];
				$email=$_POST["email"];
				$phone=$_POST["phone"];
				$day=$_POST["day"];
				$month=$_POST["month"];
				$year=$_POST["year"];
				
				$db=mysql_connect("localhost","user","1111");
				mysql_query("use test");
				$qr=mysql_query("select login from users",$db);
				$chk=0;
				for($i=0;$i<mysql_num_rows($qr);$i++)
				{
					$strs =mysql_fetch_array($qr);
					if($strs[0]==$login)
					{
						$chk=1;
					}
				}
				if($chk==0)
				{
					echo(" <br />логин: ".$_POST["login"]."<br />пароль: ".$_POST["password"]."<br />email: ".$_POST["email"]."<br />phone: ".$_POST["phone"]);
					mysql_query("INSERT INTO users(name, surname, login, password,email, phone, day, month, year) VALUES ('".$name."', '".$surname."', '".$login."', '".$password."', '".$email."', '".$phone."', '".$day."', '".$month."', '".$year."')",$db);
				}
				else
				{
					echo("такой логин уже существует");
					include("registration.php");
				}
			}
		}
		else
		{
			echo("asd");
		}
	}
	
}
else
{
	echo("вы не ввели логин!");
}






?>

</body>
</html>