<?php

session_start();
	$name=$_POST["name"];
	$surname=$_POST["surname"];
	$phone=$_POST["phone"];
	$session=$_SESSION["name"];
	mysql_connect("localhost","user","1111");
	mysql_query("use test");
	mysql_query("update users set name='$name', surname='$surname', phone='$phone' where login like '$session'");
	//echo "update users set name='$name', surname='$surname', phone='$phone' where login like '$session'";
	header("Location: index.php");
?>