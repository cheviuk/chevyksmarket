<html>
<head><link rel=stylesheet type="text/css" href=style.css></head>
<body>
<div class=menuDiv>
authorization</div><br />
<form method="post" action="proof.php">
<input type=text size=10 name="login" id="login">login
<br />
<input type=password size=10 name="password" id="password">password
<br />
<input type=submit value="����"><br />
<a href="index.php?page=registration">registration</a>
<br />
<a href="index.php?page=remember">remember</a>

</form> 
</body>
</html>

