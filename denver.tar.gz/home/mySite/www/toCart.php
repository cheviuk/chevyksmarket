<?php
	session_start();
	$id=$_GET["id"];
	$userName=$_SESSION["name"];
	if($userName=="")
	{
		echo "<META HTTP-EQUIV=refresh CONTENT=\"0;url=index.php?page=invalidAuthorization\">";
	}
	else
	{
		mysql_connect("localhost","user","1111");
		mysql_query("use test");
		$mq=mysql_query("INSERT INTO orders(userName,productID) VALUES ('$userName','$id')");

		
		
		echo "<META HTTP-EQUIV=refresh CONTENT=\"0;url=index.php?page=cart\">";
	}

?>