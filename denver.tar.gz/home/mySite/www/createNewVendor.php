<?php
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("INSERT INTO manufacturers (name) VALUES ('".$_POST["nameOfNewVendor"]."')");
	header("Location: administrator.php");
?>