<?php

	$id=$_GET["id"];
	mysql_connect("localhost","user","1111");
	mysql_query("use test");
	$mq=mysql_query("select * from products where id = $id");
	$row=mysql_fetch_array($mq);
	echo "<img src=$row[5] /> price: $row[2] <a href=toCart.php?id=$row[0]>� �������</a> <br /><br /><br />";
	echo "<div>$row[3]</div><br /><br />";
	echo "$row[4]";


?>
<?php #comments

	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	$mq=mysql_query("SELECT * FROM comments WHERE id_product = ".$_GET["id"]." ORDER BY id DESC LIMIT 5");
	while($row=mysql_fetch_array($mq))
	{
		echo "<div class=commentDiv>";
		echo "<table>";
		echo "<tr>";
		echo "<td class=comments>name: $row[2]</td>";
				echo "<td class=comments>text: $row[3]</td>";
						echo "<td class=comments>������: $row[4]</td>";
		echo "</tr>";
		echo "</table>";
		echo "</div>";
		echo "<hr />";
	}

?>
<? #add comment ?>

<br />add comment: <br />
<form name=form1 method=post action="addComment.php?id=<?php echo $_GET["id"];?>">

	name: <input type=text id=name name=name /><br />
	text: <textarea type=text id=text name=text ></textarea><br />
	rating: <select id=rating name=rating>
	<option>5</option>
	<option>4</option>
	<option>3</option>
	<option>2</option>
	<option>1</option>
	</select>
	<br /><input type=submit value=add /><br />

</form>