<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<form name=form1 id=form1 method=post action="index.php?page=passToMail">
<input type=text name=login id=login />
<input type=submit value="отправить на почту" />

</form>

</body>
</html>