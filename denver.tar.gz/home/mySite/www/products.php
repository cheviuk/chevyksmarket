<?php
	
	
	$category=$_GET["category"];
	$manufacturer=$_GET["manufacturer"];
	$pagen=$_GET["pagen"];
	$sortby=$_GET["sortby"];
	//echo "<div class=manufacturers><a href=index.php?page=category&category=>����</a></div>"
	/////////////////
	//manufacturers//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	mysql_connect("localhost","user","1111");
	mysql_query("USE test");
	
	$mq2=mysql_query("SELECT * FROM categories WHERE name LIKE '$category'");
	
	if(mysql_num_rows($mq2)!=0)
{

	$row2=mysql_fetch_array($mq2);
	
	$mq3=mysql_query("SELECT DISTINCT id_manufacturer FROM products WHERE id_category like $row2[0]");
	 
	if(mysql_num_rows($mq3)==0)
	{
		echo "��� ������ � ���� ���������!";
		return;
	}
	$queryString="SELECT * FROM manufacturers WHERE ";

	for($i=0;$i<mysql_num_rows($mq3);$i++)
	{
		
		$row4=mysql_fetch_array($mq3);
		if($i==0)
		{
			
			$queryString=$queryString."id like $row4[0] ";
		}
		else
		{
			
			$queryString=$queryString."OR id like $row4[0] ";
		}
		
	}
	
	$mq=mysql_query($queryString);
	
	echo "<div class=manufacturers>";
	
	while($row=mysql_fetch_array($mq))
	{
		if($_GET["manufacturer"]==$row[1])
			echo "|<a href=\"index.php?page=category&category=$category&manufacturer=$row[1]&pagen=1\"><span class=cur>$row[1]</span></a>|";
		else
			echo "|<a href=\"index.php?page=category&category=$category&manufacturer=$row[1]&pagen=1\">$row[1]</a>|";
			
	}
	echo "</div>";
}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	mysql_connect("localhost","user","1111");
	$mq=mysql_query("use test");
	
	if($category!="all")
	{
		
			$mqc=mysql_query("select * from categories where name like '$category' ");
			for($i=0;$i<$row=mysql_fetch_array($mqc);$i++)
			{
				$id=$row[0];
				if($_GET["manufacturer"]!="")
				{
					$mqidm=mysql_query("SELECT * FROM manufacturers WHERE name like '".$_GET["manufacturer"]."'");
					$mrow=mysql_fetch_array($mqidm);
					if($_GET["sortby"]=="")
						$mq=mysql_query("select * from products where id_category like $id AND id_manufacturer like $mrow[0]");
					else
						$mq=mysql_query("select * from products where id_category like $id AND id_manufacturer like $mrow[0] ORDER BY ".$_GET["sortby"]);
				}
				else
				{
					
					if($_GET["sortby"]=="")
						$mq=mysql_query("select * from products where id_category = $id");
					else
						$mq=mysql_query("select * from products where id_category = $id ORDER BY ".$_GET["sortby"]);
				}
			}
		
		
		
	}
	else
	{
		if($_GET["sortby"]=="")
			$mq=mysql_query("select * from products");
		else
			$mq=mysql_query("select * from products ORDER BY ".$_GET["sortby"]);
	}
		
		if($mq!=1)
		{	
				
	//////////////////////////////
	//                   pages                 //
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		echo "<div class=\"pages\">";
		for($i=0;$i<mysql_num_rows($mq)/5;$i++)
		{
			if($_GET["pagen"]!=$i+1)
			{
				
				if($_GET["manufacturer"]!="")
					echo "|<a href=\"index.php?page=category&category=".$_GET["category"]."&manufacturer=".$_GET["manufacturer"]."&pagen=".($i+1)."\">".($i+1)."</a>|";
				else
					echo "|<a href=\"index.php?page=category&category=".$_GET["category"]."&pagen=".($i+1)."\">".($i+1)."</a>|";
			}
			else
			{
				
				if($_GET["manufacturer"]!="")
					echo "|<a href=\"index.php?page=category&category=".$_GET["category"]."&manufacturer=".$_GET["manufacturer"]."&pagen=".($i+1)."\"><span class=cur>".($i+1)."</span></a>|";
				else
					echo "|<a href=\"index.php?page=category&category=".$_GET["category"]."&pagen=".($i+1)."\"><span class=cur>".($i+1)."</span></a>|";
			}
		}
		echo "</div>";
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
	
	
	
	/////////////////////////////
	//                   sort                  //
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	if($_GET["sortby"]=="name")
		echo "sort by: <a href=\"index.php?page=category&category=$category&manufacturer=$manufacturer&pagen=$pagen&sortby=name\"><span class=cur>name</span></a>";
	else
		echo "sort by: <a href=\"index.php?page=category&category=$category&manufacturer=$manufacturer&pagen=$pagen&sortby=name\">name</a>";
	if($_GET["sortby"]=="price")
		echo " <a href=\"index.php?page=category&category=$category&manufacturer=$manufacturer&pagen=$pagen&sortby=price\"><span class=cur>price</span></a>";
	else
		echo " <a href=\"index.php?page=category&category=$category&manufacturer=$manufacturer&pagen=$pagen&sortby=price\">price</a>";
		
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				$pagen=$_GET["pagen"];
				
				$s=($pagen-1)*5;
				if(mysql_num_rows($mq)<$s+5)
					$f=$s+mysql_num_rows($mq)%5;
				else
					$f=$s+5;
					
					
				$iter=0;
				for($i=0;$i<$s;$i++)
				{
					$iter++;
					mysql_fetch_array($mq);
				}
				for($i=s;$iter<$f;$i++, $iter++)
				{
					
					$rowProduct=mysql_fetch_array($mq);
					echo "<div class=\"product\"><table >";
					echo "<tr><td colspan=6><img src=$rowProduct[5] /></td></tr><tr ><td><a href=index.php?page=product&id=$rowProduct[0]>$rowProduct[1]</a></td><td>$rowProduct[2]</td><td>$rowProduct[3]</td><td>$category<br /> <a href=\"toCart.php?id=$rowProduct[0]\">� �������</a></td></tr></table></div>";
					echo "<hr />";
				}
			
			
			
		}
		else
		{
			echo "��� ������ � ���� ���������!";
		}
	
	


?>