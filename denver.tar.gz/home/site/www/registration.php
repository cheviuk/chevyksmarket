<html>
<head>
</head>
<body>
<form action="login.php" method=post id="registration">
<input type=text name="name" />name<br />
<input type=text name="surname" />surname<br />
<input type=text name="login" />login<br />
<input type=password name="password" />password<br />
<input type=password name="confirm" />confirm<br />
<input type=text name="email" />email<br />
<input type=text name="phone" />phone <br />

<?php 
	
	echo("<select>");
for($i=1;$i<32;$i++)
{
	echo("<option>".$i."</option>");
	
	
}
echo("</select>");
//
	echo("<select>");
for($i=1;$i<13;$i++)
{
	echo("<option>".$i."</option>");
	
	
}
echo("</select>");
//
	echo("<select>");
for($i=1950;$i<2000;$i++)
{
	echo("<option>".$i."</option>");
	
	
}
echo("</select><br />");

?>
<input type=button name="submit" value="���" onclick="chk();">
</form>
<script type="text/javascript">
registration.s
</script>
</body>
</html>