

#include <iostream>
#include "windows.h"
#include "stdio.h"
using namespace std;

SOCKET sock1, sock2;
sockaddr_in addr;

char buf[128] = "";
char log[128][128] = {""};
FILE* db;

SOCKET CreateSocket(const char* ip, int port = 2505);
void Receive();
void AddToLog(const char* str);
void DestroySocks(bool all = 0);
void SendLog();
bool UserOk(char*, char*);

int main(void){	
	db = fopen("db.txt", "a");
	fclose(db);
	WSADATA wsa;
	WSAStartup(MAKEWORD(2,2), &wsa);
	CreateSocket("10.0.2.196");
	for(;;){		
		Receive();
		SendLog();
		SendLog();
		DestroySocks(0);
	}

	return 0;
}

SOCKET CreateSocket(const char* ip, int port){
	int ip1, ip2, ip3, ip4;		
	addr.sin_addr.s_addr = inet_addr(ip);
	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	sock1 = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);	
	bind(sock1, (SOCKADDR*)&addr, sizeof(addr));
	listen(sock1, SOMAXCONN);
	return sock1;
}
void Receive(){
	for(;;){
		sock2 = accept(sock1, (SOCKADDR*)&addr, 0);
		if(sock2 == INVALID_SOCKET)
			Sleep(100);
		else break;
	}

	for(;;)
		if(recv(sock2, buf, 128, 0) == SOCKET_ERROR){
			Sleep(100);
		}
		else break;	


	if(strcmp(buf, "&refresh") && !strstr(buf, "&conn") && !strstr(buf, "&discon"))
		AddToLog(buf);

	if(strstr(buf, "&discon")){
		char name[128];
		char tmp[128];
		char* curs = buf + 8;
		for(int i = 0; i < 128; i++){
			if(*(curs) == ' '){
				name[i] = '\0';
				curs++;
				break;
			}
			name[i] = *curs;
			curs++;
		}
		sprintf(tmp, "*Server: %s has left the chat", name);
		AddToLog(tmp);
	}

	if(strstr(buf, "&conn")){
		char name[128];
		char pass[128];
		
		char* curs = buf + 6;
		for(int i = 0; i < 128; i++){
			if(*(curs) == ' ' || *(curs) == '\0'){
				name[i] = '\0';	
				curs++;
				break;
			}
			name[i] = *curs;
			curs++;
		}

		for(int i = 0; i < 128; i++){
			if(*(curs) == ' ' || *(curs) == '\0'){
				pass[i] = '\0';				
				break;
			}
			pass[i] = *curs;
			curs++;
		}

		if(UserOk(name, pass)){
			strcpy(buf, "&conn");
			char tmp[128];
			sprintf(tmp, "*Server: %s has joined the chat", name);
			AddToLog(tmp);
		}
		else{
			strcpy(buf, "&notconn");
		}
		send(sock2, buf, 128, 0);
	}
	
}
void DestroySocks(bool all){
	if(all)
		closesocket(sock1);
	closesocket(sock2);
}

void AddToLog(const char* str){
	char tmplog[128][128];

	for(int i = 0; i < 127; i++){
		strcpy(tmplog[i], log[i+1]);
	}
	strcpy(tmplog[127], str);
	for(int i = 0; i < 128; i++){
		strcpy(log[i], tmplog[i]);
	}
}

void SendLog(){
	system("cls");
	for(int i = 0; i < 128; i++){
		send(sock2, log[i], 128, 0);
		if(strlen(log[i]))
			cout << "Send: "<< log[i] << endl;
	}
}

bool UserOk(char* n, char* p){
	char name[128];
	char pass[128];
	db = fopen("db.txt", "r");
	while(!feof(db)){
		fscanf(db, "%s %s", name, pass);
		if(!strcmp(name, n)){
			if(!strcmp(pass, p))
				return 1;
			else
				return 0;
		}
	}
	fclose(db);
	db = fopen("db.txt", "a");
	fprintf(db, "%s %s\n", n, p);
	fclose(db);
	return 1;
}